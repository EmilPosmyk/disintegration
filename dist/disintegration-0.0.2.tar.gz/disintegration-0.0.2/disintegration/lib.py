def try_me():
    return 'successful disintegration'
